package com.example.iconpacktemplatebasic

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView


class MainActivityAdapter(private val iconImagesList1: List<Int>, private val mContext: Context) :  BaseAdapter() {

    override fun getCount(): Int {
        return iconImagesList1.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return iconImagesList1[position].toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var imageView = convertView as ImageView?

        if (imageView == null) {
            imageView = ImageView(mContext)
            // imageView.setLayoutParams(new GridView.LayoutParams(136,136)); // (imageWidth , imageHeight)
            imageView.scaleType = ImageView.ScaleType.FIT_XY
            imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE // Replace default CENTER_CROP
            // Try ScaleType.CENTER or ScaleType.CENTER_INSIDE
            imageView.adjustViewBounds = true
            imageView.setPadding(8, 8, 8, 8)
        }

        imageView.setImageResource(iconImagesList1[position])

        return imageView
    }
}