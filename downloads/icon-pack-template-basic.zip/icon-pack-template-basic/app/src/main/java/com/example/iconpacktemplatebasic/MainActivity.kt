package com.example.iconpacktemplatebasic

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Objects


class MainActivity : AppCompatActivity() {
    private var dialog: Dialog? = null // initialised here to allow access from more locations
    private var downloadPermissionGranted = false // initialised here to allow access from more locations


    private val requestMultiplePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions[Manifest.permission.READ_MEDIA_IMAGES] == true ||
            permissions[Manifest.permission.WRITE_EXTERNAL_STORAGE] == true) {

                // PERMISSION GRANTED
                downloadPermissionGranted = true
                // change download button color here!
                val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
                changeButtonColor.setBackgroundColor(-0x98af5d) // set color purple (active)
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            } else {
                // PERMISSION NOT GRANTED
                downloadPermissionGranted = false
                // change download button color here!
                val changeButtonColor: Button = dialog?.findViewById(R.id.buttonDownloadDialog1) as Button
                changeButtonColor.setBackgroundColor(-0x9a9a9b) // set color grey (inactive)
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // get a list of the icons that should be available from the res.drawable folder by parsing the drawable.xml file from the xml folder
        // the xml folder file drawable.xml is also used by Nova Launcher etc. to get the icons
        val parser = resources.getXml(R.xml.drawable)
        val list: MutableList<Int> = ArrayList()
        try {
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name == "item") {
                    for (i in 0 until parser.attributeCount) {
                        if (parser.getAttributeName(i) == "drawable") {
                            val convertedToDrawableResource =
                                "@drawable/" + parser.getAttributeValue(0)
                            val drawableResourceId = this.resources.getIdentifier(
                                convertedToDrawableResource,
                                "drawable",
                                this.packageName
                            )
                            list.add(drawableResourceId)
                        }
                    }
                }
            }
        } catch (e: XmlPullParserException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }


        // display the icons in gridView using MainActivityAdapter
        val gridView = findViewById<GridView>(R.id.icon_grid_view)
        gridView.adapter = MainActivityAdapter(list, this)
        ViewCompat.setNestedScrollingEnabled(gridView, true) // set scrollable
        gridView.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        gridView.onItemClickListener =
            OnItemClickListener { _: AdapterView<*>?, _: View?, position: Int, _: Long ->
                val itemPosition = list[position]
                showDialogBox(itemPosition)
            }
    }


    @SuppressLint("ObsoleteSdkInt")
    private fun showDialogBox(itemPosition: Int) {
        dialog = Dialog(this@MainActivity)
        dialog!!.setContentView(R.layout.activity_main_dialog)

        // remove dialog background by setting transparent and dimming to 0
        dialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog!!.window!!.setDimAmount(0f)

        // get px value (pixels) for 450dp (a reasonable dialog box size)
        val scale = resources.displayMetrics.density
        val pixels = (450 * scale + 0.5f).toInt()

        // get width of the screen in pixels
        val width = resources.displayMetrics.widthPixels

        // if screen is wider than the dialog box, limit the maximum size of the dialog to 450dp
        if (width > pixels) {
            dialog!!.window!!.setLayout(pixels, ViewGroup.LayoutParams.WRAP_CONTENT)
        } else { // if screen is narrower than the dialog box, fill the parent to ensure maximum dialog size
            dialog!!.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // code to make headings using the drawable names
        val dialog1Text = dialog!!.findViewById<TextView>(R.id.textDialog1)
        val title = resources.getResourceName(itemPosition)

        //extracting name
        val index = title.indexOf("/")
        val name = title.substring(index + 1)
        dialog1Text.text = name

/*
//        // alt code to above - to make headings from icon_pack.xml string-array "all" if added to values
//        TextView dialog1_text = dialog.findViewById(R.id.textDialog1);
//        // uses position from iconImage1 to call text from array all
//        String name = getResources().getStringArray(R.array.all)[position];
//        dialog1_text.setText(name);
*/

        // code to show the image
        val dialog1Image = dialog!!.findViewById<ImageView>(R.id.imageDialog1)
        dialog1Image.setImageResource(itemPosition)

        // close button
        val dialog1Close = dialog!!.findViewById<Button>(R.id.buttonCloseDialog1)
        dialog1Close.setOnClickListener { dialog!!.dismiss() }

        // download button
        val dialog1Download = dialog!!.findViewById<Button>(R.id.buttonDownloadDialog1)

        // initial check to see if permission to download is given and set download permissionGranted and button color accordingly
        if (Build.VERSION.SDK_INT >= 33) {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                dialog1Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog1Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        } else {
            downloadPermissionGranted = if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                dialog1Download.setBackgroundColor(-0x98af5d)
                true
            } else {
                dialog1Download.setBackgroundColor(-0x9a9a9b)
                false
            }
        }


        dialog1Download.setOnClickListener {
            // if not already given request permissions
            if (!downloadPermissionGranted) {

                if (Build.VERSION.SDK_INT >= 33) {
                    requestMultiplePermissions.launch(
                    arrayOf(
//                        Manifest.permission.READ_MEDIA_AUDIO, // not used for this app
//                        Manifest.permission.READ_MEDIA_VIDEO, // not used for this app
                        Manifest.permission.READ_MEDIA_IMAGES // >= 33 you need to add any permission to allow saving files to internal Downloads
                    )
                )
                } else {
                    requestMultiplePermissions.launch(
                    arrayOf(
//                        Manifest.permission.CAMERA, // not used for this app
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                )
                }
            } else {
                try {
                    onClickDownload1(name)
                } catch (e: IOException) {
                    // throw RuntimeException(e)
                    // log the exception
                    Toast.makeText(this@MainActivity, "Error Downloading $name, It Possibly Already Exists?", Toast.LENGTH_LONG).show()
                }

//                dialog!!.dismiss() // moved to onClickDownload1(name)
            }
        }

        dialog!!.show()
    }


    @Throws(IOException::class)
    private fun onClickDownload1(name: String) {
        val downloadName = "$name.png"
        val downloadResource = "@drawable/$name"
        val drawableResourceId = this.resources.getIdentifier(downloadResource, "drawable", this.packageName)

        val o = BitmapFactory.Options()
        o.inScaled = false // convert image to bitmap without the automatic rescaling
        val bitmapInputImage = BitmapFactory.decodeResource(this.resources, drawableResourceId, o)
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmapInputImage.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val bytesArray = byteArrayOutputStream.toByteArray()
        try {
            val fileOutput: File = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { // possibly use Build.VERSION_CODES.N instead
                val storageManager = getSystemService(STORAGE_SERVICE) as StorageManager
                val storageVolume = storageManager.storageVolumes[0] // internal storage

                File(Objects.requireNonNull((storageVolume.directory)?.path) + "/Download/" + downloadName)
            } else {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), downloadName)
            }
            val fileOutputStream = FileOutputStream(fileOutput)
            fileOutputStream.write(bytesArray)
            fileOutputStream.flush()
            fileOutputStream.close()
            // close the dialog
            dialog!!.dismiss()
            Toast.makeText(this@MainActivity, "$downloadName Saved In Download Folder", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this@MainActivity, "Couldn't Save The Icon", Toast.LENGTH_LONG).show()
        }
    }

}